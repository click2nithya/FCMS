$(document).on('click','#save_btn',function(e) {	
		var assettype=$("#asset_type").val();
    var floorNo=$("#floorNo").val();
    var trainingType=$("#training_Type").val();
    var workStatus=$("#work_status").val();
     
    if($.trim(assettype)=='')
    {
        toastr.error('Please Enter Asset Type!');
        return false;
    }
    else  if($.trim(floorNo)=='')
    {
        toastr.error('Please Enter Floor numbers!');
        return false;
    }	
     else  if($.trim(trainingType)=='')
    {
        toastr.error('Please Enter Training Type!');
        return false;
    }	
     else  if($.trim(workStatus)=='')
    {
        toastr.error('Please Enter Work Status!');
        return false;
    }	
	e.preventDefault();
    var data = $("#settingsForm").serialize();
    $.ajax({
      data: data,
      type: "post",
      url: "backend/save.php",
      success: function(dataResult){
          var dataResult = JSON.parse(dataResult);
          if(dataResult.statusCode==200){
          alert('General Settings updated successfully !'); 
          location.reload();            
          }
          else if(dataResult.statusCode==201){
             alert(dataResult);
          }
      }
    });
  });
