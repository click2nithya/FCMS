<style>
#footer{
  background:#036965;
  position:absolute;
  width: 100%;
  left:0px;
  height: 240px;
  margin-top: 100px;
  border-top:8px solid #00948f;
  clear:both;
  padding-top: 10px;

}


.footer-containt-table{
  width: 80%;
  padding: 15px;
}


.f1cSub{
  font-family: sans-serif;
  color:#9ce2e0;
  font-size: 18px;
}

.f1cSub td{
 padding: 10px;
}

</style>


<section id="footer">

  <table border="0" class="footer-containt-table">

    <tr>

      <td>
        <!--..................-->
    <img src="imgs/logoFindex3.png" width="220">
      <!--..................-->
    </td>

      <td class="f1c">
        <!--..................-->
        <table class="f1cSub">
          <tr>
          <tr>  <td align='center'> <img src="imgs/l-ico.png" width="20"> </td> <td> Kingdom of Saudi Arabia </td>  </tr>
          <tr>  <td align='center'> <img src="imgs/m-ico.png" width="20"> </td> <td> P. O. Box 3551777 Riyadh 11383 </td>  </tr>
          <tr>  <td align='center'> <img src="imgs/t-ico.png" width="22"> </td> <td> 0114081666 </td>  </tr>
          <tr>  <td align='center'> <img src="imgs/e-ico.png" width="20"> </td> <td>  info@rpi.edu.sa  </td>  </tr>
          </tr>
        </table>
        <!--..................-->
      </td>


      <td>
        <!--..................-->
        <table>
          <tr>
          <tr>  <td> </td>  </tr>
          <tr>  <td>  </td>  </tr>
          </tr>
        </table>
        <!--..................-->
      </td>






      <td align="right">
        <!--..................-->
        <table>
          <tr>
          <tr>
            <td> <a href="#">  <img src="imgs/instagram2.png" id="xi" onmouseover="changePhoto('instagram','i',1);" onmouseout="changePhoto('instagram','i',2);" width="80"> </a> </td>
            <td></td>
            <td> <a href="https://twitter.com/rpi_sa">  <img src="imgs/twitter2.png" id="xt" onmouseover="changePhoto('twitter','t',1);" onmouseout="changePhoto('twitter','t',2);" width="80"> </a> </td>
          </tr>
          <tr>
            <td> <a href="#">  <img src="imgs/linkedin2.png" id="xl" onmouseover="changePhoto('linkedin','l',1);" onmouseout="changePhoto('linkedin','l',2);" width="80"> </a> </td>
            <td></td>
            <td> <a href="https://www.snapchat.com/add/rpi.sm">  <img src="imgs/snapchat2.png" id="xs" onmouseover="changePhoto('snapchat','s',1);"  onmouseout="changePhoto('snapchat','s',2);" width="80"> </a> </td>
          </tr>
          </tr>
        </table>
        <!--..................-->
      </td>






    </tr>


  </table>

</section>

<?

?>
