<?
session_start();
?>



<style media="screen">
body{
  background: url("imgs/background.png");
  background-repeat: repeat;
  background-attachment: fixed;
}

  #subOption1 ,#subOption2{
    background: rgb(14, 143, 135);
  }

  #subOption1x ,#subOption2x,#subOption1x_2 ,#subOption2x_2,#subOption3x_2{
    background: rgb(14, 143, 135);
  }
</style>


<ul class='header_menu'>
  <?php
  $rpi_perm="admin";
  $rpi_email="mohammed.alenazi@rpi.edu.sa";
  $rpi_FullName='Nithya';
$rpi_eml="mohammed.alenazi@rpi.edu.sa";
    if($rpi_perm!=='stu'){

  echo"<li> <img src='imgs/menu.png' width='30'>
      <ul class='side_menu'>";

          if($rpi_perm=="registrar" || $rpi_perm=="admin" || $rpi_perm=="acadimic_admin" || $rpi_perm=="acadimic"|| $rpi_perm=="Teacher"){ echo" <li> <a href='queries.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/support.png' width='20'></td> <td class='ms-text'>Search</td>  </tr></table>  </a></li> ";}
          if($rpi_perm=="registrar"){
            echo"
            <li> <a href='#' onclick='showSubOptionX();'> <input type='hidden' value='0' id='showSubOptionText'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add.png' width='18'></td> <td class='ms-text'> New Trainees </td>  </tr></table>  </a></li>
            <li id='subOption1' style='display:none;'> <a href='AddTrainee.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> Individually </td>  </tr></table>  </a></li>
            <li id='subOption2' style='display:none;'> <a href='ViewNewTranees.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> bulk  </td>  </tr></table>  </a></li>
           ";
         }
         if($rpi_email=="mohammed.alenazi@rpi.edu.sa"){
           echo" <li> <a href='TranscriptStatus.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Transcript status </td>  </tr></table>  </a></li> ";
		   echo" <li> <a href='ScheduleTableAdminUpdate.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Update Schedule</td>  </tr></table>  </a></li> ";
		   echo" <li> <a href='ChangeSections.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Change Sections</td>  </tr></table>  </a></li> ";
         }
          if($rpi_perm=="acadimic"){
            echo" <!--<li> <a href='CreateLecturTable.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Create schedules </td>  </tr></table>  </a></li>--> ";
            echo" <li> <a href='CalSet.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Create Academic Calendar </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='viewAllTables.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> view All schedules </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='AddSpecialty.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add.png' width='18'></td> <td class='ms-text'> Add Majors </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='CourseDetails.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Courses Details </td>  </tr></table>  </a></li> ";
          }
          if($rpi_perm=="acadimic_admin"||$rpi_perm=="acadimic"||$rpi_perm=="admin"){
            echo" <li> <a href='getMajors.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Majors </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='changeCourse.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Courses </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='all_classroom.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='18'></td> <td class='ms-text'> classrooms </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='AddTeacher.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add_teacher.png' width='22'></td> <td class='ms-text'> Instructions </td>  </tr></table>  </a></li> ";
          }
          if($rpi_perm=="acadimic_admin"||$rpi_perm=="acadimic"||$rpi_perm=="admin"||$rpi_perm=="registrar"||$rpi_perm=="liv"|| $rpi_perm=="acadimic_super"){
            echo" <li> <a href='GradingReport.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Grading Report </td>  </tr></table>  </a></li> ";
          }
          if($rpi_perm=="acadimic"){ echo" <li> <a href='AddCourse.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add.png' width='18'></td> <td class='ms-text'> Add Courses </td>  </tr></table>  </a></li> ";}
          if($rpi_perm=="registrar"||$rpi_perm=="acadimic_admin"||$rpi_perm=="acadimic"||$rpi_perm=="admin"){
             echo" <li> <a href='#'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/inbox.png' width='18'></td> <td class='ms-text'> Archives </td>  </tr></table>  </a></li> ";
           }

          if($rpi_perm=="admin"){
            echo" <li> <a href='AttendeesReport.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/inbox.png' width='18'></td> <td class='ms-text'> Attendees </td>  </tr></table>  </a></li> ";
          }

          if($rpi_perm=="acadimic_admin"){
            echo" <li> <a href='PassRate.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/inbox.png' width='18'></td> <td class='ms-text'> Pass Rate </td>  </tr></table>  </a></li> ";
          }

          if($rpi_perm=="Teacher"){
            echo" <li> <a href='Tea_course.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/inbox.png' width='18'></td> <td class='ms-text'> Grades </td>  </tr></table>  </a></li> ";
          }

          if($rpi_perm=="registrar"||$rpi_perm=="acadimic_admin" ||$rpi_perm=="acadimic" || $rpi_perm=="acadimic_super"|| $rpi_perm=="liv" || $rpi_email=="waleed.hassan@rpi.edu.sa"){
            echo"
            <li> <a href='#' onclick='showSubOptionXx();'> <input type='hidden' value='0' id='showSubOptionText2'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add.png' width='18'></td> <td class='ms-text'> Attendees </td>  </tr></table>  </a></li>
            <li id='subOption1x' style='display:none;'> <a href='AttendeesReport.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> All Trainees </td>  </tr></table>  </a></li>
            <li id='subOption2x' style='display:none;'> <a href='Alarms.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> Warning Report  </td>  </tr></table>  </a></li>
            ";
          }

          if($rpi_perm=="acadimic_super"||$rpi_perm=="acadimic_admin"){
            echo"
            <li> <a href='#' onclick='showSubOptionXx2();'> <input type='hidden' value='0' id='showSubOptionText2_2'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add.png' width='18'></td> <td class='ms-text'> Manage training plan </td>  </tr></table>  </a></li>
            <li id='subOption1x_2' style='display:none'> <a href='ManageTP.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> Add New Plan </td>  </tr></table>  </a></li>
            <li id='subOption2x_2' style='display:none'> <a href='viewPlans.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> View Plans  </td>  </tr></table>  </a></li>
            <li id='subOption3x_2' style='display:none'> <a href='linkPlans.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/add5.png' width='18'></td> <td class='ms-text'> Link Plans  </td>  </tr></table>  </a></li>
            ";
          }

          if($rpi_perm=="admin"){
            echo" <li> <a href='q_evaluation.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Survay Questions  </td>  </tr></table>  </a></li> ";
            echo" <li> <a href='tips.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Add TIPs  </td>  </tr></table>  </a></li> ";
          }

         if($rpi_perm=='hr_admin'){
           echo" <li> <a href='attRoles.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Attendance Rules  </td>  </tr></table>  </a></li> ";
           echo" <li> <a href='addvc.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Vacations  </td>  </tr></table>  </a></li> ";
               }

          if($rpi_email=="waleed.hassan@rpi.edu.sa"|| $rpi_email=="mohammed.alenazi@rpi.edu.sa"||$rpi_email=="montaser.yousif@rpi.edu.sa"||$rpi_email=="waleed.hassan@rpi.edu.sa"){
            echo" <li> <a href='EditAttendees.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Attendance update </td>  </tr></table>  </a></li> ";
              }

          if($rpi_email=="exam.iv@rpi.edu.sa"||$rpi_perm=="acadimic"|| $rpi_perm=="acadimic_super"){
              echo" <li> <a href='Assessments.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> All Assessments </td>  </tr></table>  </a></li> ";
          }

             echo" <li> <a href='ViewCalender.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/view2.png' width='22'></td> <td class='ms-text'> Academic Calendar </td>  </tr></table>  </a></li> ";
             echo" <li> <a href='profile.php'> <table class='sideMenuTab' width='100%' border='0'><tr> <td class='ms-ico'><img src='imgs/profile.png' width='25'></td> <td class='ms-text'> Profile </td>  </tr></table>  </a></li> ";

             echo" <li class='ulSideFooter'> </li> ";

    echo"</ul></li>";

}
if($rpi_perm=='stu'){echo"<li class='supr_li'></li>";}



  //if($rpi_perm=='rpi_coor'||$rpi_perm=='rpi_super'||$rpi_perm=='company_super'||$rpi_perm=='company_hr'||$rpi_perm=='acadimic_super'){echo"<li class='Hi_class'> <a href='sharik.php'> Sharik </a> </li>";}

  if($rpi_perm=='stu'){
    echo"
    <li class='orderLi'><a href='orders/orders.php'> Request  </a>
    ";
  }

  echo"
  <li class='user_li' style='float:right;width:110px'><table class='Hi_class'><tr> </td> <td>Hi,</td>  <td>".$rpi_FullName."</tr></table>  </li>
  <li style='width:400px;'>
  <table class='Hi_class'>
  <tr><td valign=middle><a href='Home.php' >TIP</a></td>";
 $sujectpage='';
 if ($sujectpage!="")
  {
  echo"<td valign=middle><img src='imgs\arrow.png' width=25></td>
  <td valign=middle>";
  if ($sujectpagelink!="")
  echo"<a href='$sujectpagelink' >";
  
  echo $sujectpage;
  if ($sujectpagelink!="")
  echo"</a>";
  echo"</td>";
  }
  $sujectpage1="";
  if ($sujectpage1!="")
  echo"<td valign=middle><img src='imgs\arrow.png' width=25></td>
  <td valign=middle>".$sujectpage1."</td>";
  
  echo"</tr>"; 
  echo"</table>";
  echo"</li>";		



  echo"
  </li>


   <!--<li style='float:right'>
       ";
       if($_SESSION['rpi_login_type']=='google'){
           echo "<a href='login_with_google_using_php/logout.php'> Sign out </a> ";
       }
       else{
         echo "<a href='logout.php'> Sign out </a></li>--> ";
       }

       ?>


        
        <!--<li style='float:right'> <a href='#'> <img class='small_logo' src='<?php if($UD_ProfileImage){echo 'ticket/UserImages/'.$UD_ProfileImage;}else{echo 'imgs/logo.png';}?>' width='40'> </a> </li>-->
 
 <?

        if($rpi_perm=='rpi_coor'||$rpi_perm=='rpi_super'||$rpi_perm=='company_super'||$rpi_perm=='company_hr'||$rpi_perm=='acadimic_admin'){
        //echo"<li style='float:right;width:50px'> <a href='#'> <img class='small_logo' src='imgs/sharik.png' width='30'> </a> </li> ";
        }
        ?>
	
<li style='float:right' class='notifcation_li'>
          <img src="<?php if($UD_ProfileImage){echo 'ticket/UserImages/'.$UD_ProfileImage;}else{echo 'imgs/logo.png';}?>" 
		  onclick="information_ul()" class="small_logo"  
style='position:relative;top:-4px;cursor:pointer'
		  width="30"/><!--id="notif_status"-->
          <input type='hidden' value='0' id='information_text'/>


     <ul class='notifcation_ul' style='display:none' id='information_ul' style="width:100px">
        
		   <li class='delcSp'>  <img src='imgs/up_arrow.png' width='25' class='arrowUp_notify'/> <div>  </div> </li>
		  
			 
                               <li class='delcx' >    
								<center><table border='0' width='95%'><tr>    
								<td style='text-align:center'><a href='profile.php' style="color:#3ca08c;"
													onMouseOver="this.style.color='#3ca08c'" onMouseOut="this.style.color='#3ca08c'"> Profile </a> </td> </tr></table>  
								</center></li>
                                
                                <li class='delcx' >    
								<center><table border='0' width='95%'><tr>    
								<td style='text-align:center'><a href='logout.php' style="color:#3ca08c;"
													onMouseOver="this.style.color='#3ca08c'" onMouseOut="this.style.color='#3ca08c'"> Sign out </a> </td> </tr></table>  
								</center></li>
								
                        
			
     </ul>
   </li>
   
		
        <li style='float:right' class='notifcation_li'>
          <img src='imgs/ball-off.png' onclick='notifcation_ul()' id='notif_status' style='position:relative;top:-4px;cursor:pointer' width='35'/>
          <input type='hidden' value='0' id='notif_text'/>


     <ul class='notifcation_ul' style='display:none' id='notifcation_ul'>
       <?
       echo"<li class='delcSp'>  <img src='imgs/up_arrow.png' width='25' class='arrowUp_notify'/> <div>  </div> </li>";
     //..........................delete massage permission...................//
      if($rpi_perm=='admin'){

              echo"
              <li class='delcx' onclick='GoDeleteReq()'><center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_delete'> no </td>   <td style='text-align:left'> <div> Status Change Requests </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoReqILP()'>   <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_ilp'> no </td>   <td style='text-align:left'> <div> ILP - Risk Cases Report </div> </td> </tr></table>  </center></li>
			  <li class='delcx' onclick='Gostudentstoapprove()'> <center><table border='0' width='95%'><tr> <td align='left' class='num_notification_css_normal' id='num_studentstoapprove_request'> no </td>   <td style='text-align:left'> <div> New Batch approval </div> </td> </tr></table>  </center></li>
              ";
              }
    else if(($rpi_perm=='acadimic_admin')){
	
              echo"
              <li class='delcx' onclick='GoDeleteReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_delete'> no </td>   <td style='text-align:left'> <div> Status Change Requests  </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoChangeReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_change'> no </td>   <td style='text-align:left'> <div> Major Change Request    </div> </td> </tr></table>  </center></li>";
			  
              echo"<li class='delcx' onclick='GoShGradesReq()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_sh'> no </td>   <td style='text-align:left'> <div> Sharik Grades Requests </div> </td> </tr></table>  </center></li>";
			  
              echo"<li class='delcx' onclick='GoReqILP()'>       <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_ilp'> no </td>   <td style='text-align:left'> <div> ILP - Risk Cases Report </div> </td> </tr></table>  </center></li>";
              }

      else if($rpi_perm=='liv' || $rpi_perm=='acadimic_super'){
           echo"
           <li class='delcx' onclick='GoAsDateReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_asDate'> no </td>   <td style='text-align:left'> <div> Asessment Dates Request </div> </td> </tr></table>  </center></li>
           <li class='delcx' onclick='GoGradesReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_greads'> no </td>   <td style='text-align:left'> <div> Grades  Requests </div> </td> </tr></table>  </center></li>
           <li class='delcx' onclick='GoEditGrReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_Egreads'> no </td>   <td style='text-align:left'> <div> Edit Grade Requests </div> </td> </tr></table>  </center></li>
           ";
           }

      else if($rpi_perm=='registrar'){
              echo"
              <li class='delcx' onclick='GoformReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_Form'> no </td>   <td style='text-align:left'> <div> ID Letter Request </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoAbsenceReq()'> <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_absence'> no </td>   <td style='text-align:left'> <div> Excused Absence Request </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoChangeReq()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_change'> no </td>   <td style='text-align:left'> <div> Major Change Request </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoDeleteReq()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_delete'> no </td>   <td style='text-align:left'> <div> Change Status Request </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoReqILP()'>       <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_ilp'> no </td>   <td style='text-align:left'> <div> ILP - Risk Cases Report </div> </td> </tr></table>  </center></li>
              ";
              }

      else if($rpi_perm=='acadimic'){
              echo"
              <li class='delcx' onclick='GoReqILP()'>   <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_ilp'> no </td>   <td style='text-align:left'> <div> ILP - Risk Cases Report </div> </td> </tr></table>  </center></li>
              ";
              }

      else if($rpi_perm=='stu'){
                echo"
                <li class='delcx' onclick='GoformReqStu()'>     <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_Form'> no </td>   <td style='text-align:left'> <div> ID letter Request </div> </td> </tr></table>  </center></li>
                <li class='delcx' onclick='GoAbsenceReqStu()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_absence'> no </td>   <td style='text-align:left'> <div> Excused Absence Request </div> </td> </tr></table>  </center></li>
                <li class='delcx' onclick='GoChangeReqStu()'>   <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_change'> no </td>   <td style='text-align:left'> <div> Major Change Request </div> </td> </tr></table>  </center></li>
                ";
                }
       else if($rpi_perm=='rpi_coor'){
                echo"
                <li class='delcx' onclick='GoShGradesCoor()'>     <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_ShGradesCoor'> no </td>   <td style='text-align:left'> <div> Request Coordinator </div> </td> </tr></table>  </center></li>

                ";
                }
       else if($rpi_perm=='Teacher'){
              echo"
              <li class='delcx' onclick='GoAsDateReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_asDate_t'> no </td>   <td style='text-align:left'> <div> Asessment Dates Request </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoGradesReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_greads_t'> no </td>   <td style='text-align:left'> <div> Grades Requests </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoEditGrReq()'>    <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_Egreads'> no </td>   <td style='text-align:left'> <div> Edit Grade Requests </div> </td> </tr></table>  </center></li>
              <li class='delcx' onclick='GoReqshr()'>       <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_shr'> no </td>   <td style='text-align:left'> <div> Supervising trainees (Sharik) </div> </td> </tr></table>  </center></li>
              ";
              }

              //$$$$$$$$$$$$$$$$$----Sharik Menus----$$$$$$$$$$$$$$$$$//

   else if($rpi_perm=='company_super'||$rpi_perm=='rpi_super'){
              echo"
              <li class='delcx' onclick='GoSharikGradesReq()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_greads_t'> no </td>   <td style='text-align:left'> <div> Sharik Grades  Requests </div> </td> </tr></table>  </center></li>
              ";
          }

     else if($rpi_perm=='company_hr'){
                echo"
                <li class='delcx' onclick='GoSharikGradesReq()'>  <center><table border='0' width='95%'><tr>  <td align='left' class='num_notification_css_normal' id='num_req_grads_hr'> no </td>   <td style='text-align:left'> <div> Sharik Grades  Requests </div> </td> </tr></table>  </center></li>
                ";
            }

              //$$$$$$$$$$$$$$$$$----Sharik Menus----$$$$$$$$$$$$$$$$$//

              echo"<li>  <div>  </div> </li>";
     //......................end delete massage permission...................//
       ?>

     </ul>
   </li>
   

</ul>

<div id="GNotifyTimer_container"></div>

<script type='text/javascript'>


function notifcation_ul() {
 var ntx=document.getElementById("notif_text").value;
  if(ntx==0){
    document.getElementById("notifcation_ul").style.display="block";
	   if (document.getElementById("information_ul").style.display=="block")
	    {
		   document.getElementById("information_ul").style.display="none";
		   document.getElementById("information_text").value=0;
	    }
    document.getElementById("notif_text").value=1;
  }
  else{
    document.getElementById("notifcation_ul").style.display="none";
	
    document.getElementById("notif_text").value=0;
  }

  $.ajax({
    type:"post",
    url:"classes/User_notify.php",
    data:"",
    beforeSend:function () {},
    success:function (data) {
       GNotifyTimer();
    }
  });

}

function information_ul() {
  var ntx=document.getElementById("information_text").value;
  if(ntx==0){

    document.getElementById("information_ul").style.display="block";
	  if (document.getElementById("notifcation_ul").style.display=="block")
	    {
		   document.getElementById("notifcation_ul").style.display="none";
		   document.getElementById("notif_text").value=0;
	    }
    document.getElementById("information_text").value=1;
  }
  else{
    document.getElementById("information_ul").style.display="none";
	
    document.getElementById("information_text").value=0;
  }

  

}

function showSubOptionX() {
  var SubOpText=document.getElementById('showSubOptionText').value;
  if(SubOpText==0){
  document.getElementById('showSubOptionText').value=1;
  document.getElementById('subOption1').style.display="block";
  document.getElementById('subOption2').style.display="block";
   }
   else{
     document.getElementById('showSubOptionText').value=0;
     document.getElementById('subOption1').style.display="none";
     document.getElementById('subOption2').style.display="none";
   }
}


function showSubOptionXx() {
  var SubOpText=document.getElementById('showSubOptionText2').value;
  if(SubOpText==0){
  document.getElementById('showSubOptionText2').value=1;
  document.getElementById('subOption1x').style.display="block";
  document.getElementById('subOption2x').style.display="block";
   }
   else{
     document.getElementById('showSubOptionText2').value=0;
     document.getElementById('subOption1x').style.display="none";
     document.getElementById('subOption2x').style.display="none";
   }
}


function showSubOptionXx2() {
  var SubOpText=document.getElementById('showSubOptionText2_2').value;
  if(SubOpText==0){
  document.getElementById('showSubOptionText2_2').value=1;
  document.getElementById('subOption1x_2').style.display="block";
  document.getElementById('subOption2x_2').style.display="block";
  document.getElementById('subOption3x_2').style.display="block";
   }
   else{
     document.getElementById('showSubOptionText2_2').value=0;
     document.getElementById('subOption1x_2').style.display="none";
     document.getElementById('subOption2x_2').style.display="none";
     document.getElementById('subOption3x_2').style.display="none";
   }
}

function ReqAproveDel(id,ptyp) {
  //alert(id+'-'+ptyp);
  var xi=confirm(" Are you sure of the procedure ");
  if(xi==1){
  $.ajax({
    type:"post",
    url:"ReqAproveDel.php",
    data:"stu_id="+id+"&app_typ="+ptyp,
    beforeSend:function () {},
    success:function(res){
  GetAllTranee_delReq();
  GNotifyTimer();
    }
  });
}
}

setInterval(function () {GNotifyTimer();} ,2000);

function GNotifyTimer() {

  $.ajax({
    type:"post",
    url:"notify_value.php",
    data:"",
    beforeSend:function () {},
    success:function(data){
      $("#GNotifyTimer_container").html(data);
    }
  });

}

$(document).ready(function() {
  GNotifyTimer();
});

function GoDeleteReq() {
  window.location.href ="GoDeleteReq.php";
//  header("location:GoDeleteReq.php");
}

function Gostudentstoapprove() {
  window.location.href ="studentstoapproveceo.php";
//  header("location:GoDeleteReq.php");
}

function GoformReq() {
  window.location="GoFormReq.php";
}

function GoformReqStu() {
  window.location="GoFormReqStu.php";
}
function GoShGradesCoor() {
  window.location="GoShGradesCoor.php";
}
function GoAbsenceReqStu() {
  window.location="GoAbsenceReqStu.php";
}

function GoChangeReqStu() {
  window.location="GoChangeReqStu.php";
}

function GoChangeReq() {
  window.location="GoChangeReq.php";
}

function GoAbsenceReq() {
  window.location="GoAbsenceReq.php";
}

function GoAsDateReq() {
  window.location="GoAsessDateReq.php";
}


function GoGradesReq() {
  window.location="GoGradesReq.php";
}

function GoEditGrReq() {
  window.location="GoEditGradeReq.php";
}

function GoReqshr() {
  window.location="GoReqShr.php";
}

function GoReqILP() {
  window.location="GoReqILP.php";
}

function GoSharikGradesReq() {
  window.location="GoSharikGradesReq.php";
}

function GoShGradesReq() {
  window.location="GoShGradesReq.php";
}

function GetAllTranee_FormReq() {
  $.ajax({
    type:"post",
    url:"get_AllTraneeFormReq.php",
    data:"",
    beforeSend:function () {},
    success:function(Result){
        $("#GNT_container").html(Result);
    }
  });
}


/*....................automatic logout...........................*/
   setInterval(function () {
       var logCo=document.getElementById('logout_count').value;
       var loo=parseInt(logCo);
       if(loo < 300){
         var newLogCo=parseInt(loo)+1;
         document.getElementById('logout_count').value=newLogCo;
       }
       else{
         window.location='logout.php';
       }
     },1000);

     window.addEventListener('mouseover', function() {
       document.getElementById('logout_count').value=0;
     });

     window.addEventListener('keydown', function() {
       document.getElementById('logout_count').value=0;
     });

     window.addEventListener('click', function() {
       document.getElementById('logout_count').value=0;
     });



/*...................end automatic logout........................*/
</script>
<be><be><br><br><br>
<input type='hidden' value='0' id='logout_count'>

