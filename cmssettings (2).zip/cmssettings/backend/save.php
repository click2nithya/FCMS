<?php
include 'database.php';
 mysqli_query( $conn,'TRUNCATE TABLE `general_settings`'); 

    $slug=array_keys($_REQUEST);
    $value=array_values($_REQUEST);
    $insert = "";
     for($i=0;$i<count($_REQUEST);$i++){
         if($i == 0){
            $insert = "('". $slug[$i]."','". $value[$i]."')";
         }else{
            $insert .= ",('". $slug[$i]."','". $value[$i]."')";
         }
     }
        $sql = "insert into general_settings(`slug`, `value`) VALUES ".$insert;
      if (mysqli_query($conn, $sql)) {
      echo json_encode(array("statusCode"=>200));
    } 
    else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

 

?>