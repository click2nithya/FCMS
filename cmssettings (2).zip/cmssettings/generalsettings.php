<?php 
include('header.php');
include('backend\database.php');

?>
<title>General Settings</title>
<link rel="stylesheet" href="css/style.css"> 
<link rel="stylesheet" href="css/toastr.css">

<script src="js/jquery-3.6.0.min.js"></script> 
<script src="js/toastr.js"></script>	 
<style>
	.form-control {
  display: block;
  width: 90%;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

</style>
<?php  
$sql = 'SELECT slug,value from general_settings';
$query = mysqli_query($conn,$sql);
$data = mysqli_fetch_all ($query);
?>
<div class="container" style="margin: auto;
  width: 50%;
  border: 3px solid green;
  padding: 10px;">	
	<h2>General Settings</h2>	
	  		<form id="settingsForm" style="line-height: 140%;">
    			   <div class="row">
      					<div class="col-md-12">
						<div class="form-group">
							<label for="asset_type" class="control-label">Type</label>
							<input type="text" class="form-control" id="asset_type" name="asset_type" placeholder="Asset Type" value="<?php if($data[0][0]=='asset_type'){ echo $data[0][1];}?>" required>	
							<span style="color:green;">add value by comma sepration</span>		
						</div>
					</div>
				</div>
				  <div class="row">
      				<div class="col-md-12">
						<div class="form-group">
							<label for="floorNo" class="control-label">Floor No</label>							
							<input type="text" class="form-control" id="floorNo" name="floorNo" placeholder="floorNo" value="<?php if($data[1][0]=='floorNo'){ echo $data[1][1];}?>" >
							<span style="color:green;">add value by comma sepration</span>								
						</div>	
						</div>
						</div>   
						 <div class="row">
      				<div class="col-md-12">	
						<div class="form-group">
							<label for="training_Type" class="control-label">Training Type</label>							
							<input type="text" class="form-control"  id="training_Type" name="training_Type" placeholder="Training Type" value="<?php if($data[2][0]=='training_Type'){ echo $data[2][1];}?>">
							<span style="color:green;">add value by comma sepration</span>							
						</div>	
						</div>
						</div>
						 <div class="row">
      				<div class="col-md-12"> 
						<div class="form-group">
							<label for="work_status" class="control-label">Status</label>							
							<input type="text" class="form-control"  id="work_status" name="work_status" placeholder="Work Status" value="<?php if($data[3][0]=='work_status'){ echo $data[3][1];}?>">
							<span style="color:green;">add value by comma sepration</span>							
						</div>	 
						 </div>
						 </div>
						  <div class="row" style="text-align: center;">
      				<div class="col-md-12">		    				 
    				<div class="form-group">
    					<input type="submit" name="save_btn" id="save_btn" class="btn btn-info" value="Save" />
    				</div> 
    			</div>
    		</div>
    		</form>
    
</div>	

<script src="js/script.js"></script>	

<?php include('footer.php');?>

